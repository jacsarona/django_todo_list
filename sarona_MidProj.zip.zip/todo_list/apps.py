from django.apps import AppConfig


class TodoList1Config(AppConfig):
    name = 'todo_list1'
